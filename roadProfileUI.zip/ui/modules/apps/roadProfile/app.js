// 路面抓包 游戏内 App —— 实时面板
// 数据来源：扩展的 getLive()（GE 侧增量统计，查询零成本）
angular.module('beamng.apps')

.directive('roadProfile', ['$interval', function ($interval) {
  return {
    templateUrl: '/ui/modules/apps/roadProfile/app.html',
    replace: true,
    restrict: 'E',
    scope: true,
    link: function (scope, element, attrs) {
      scope.d = {
        recording: 0, samples: 0, dist: 0, level: '-', n: 0,
        vAvg: 0, vMax: 0, rmsF: 0, rmsR: 0,
        hFc: [], hFr: [], hRc: [], hRr: [], bins: [],
        load: {}, loadNow: {}, airPct: {}, compSign: 1
      }
      scope.groups = []
      scope.alive = false

      scope.msg = ''

      function build(d) {
        // 时长 / 里程 / 车速换成好读的单位
        var n = parseInt(d.samples || 0, 10)
        var sec = n / 10.0
        var mm = Math.floor(sec / 60), ss = Math.floor(sec % 60)
        d.durText = (mm > 0 ? mm + '分' : '') + ss + '秒'
        d.distKm = ((parseFloat(d.dist) || 0) / 1000).toFixed(2)
        var va = parseFloat(d.vAvg) || 0, vm = parseFloat(d.vMax) || 0
        d.vAvgKmh = Math.round(va * 3.6)
        d.vMaxKmh = Math.round(vm * 3.6)

        // 四组柱子按「全局最高 bin」归一化，这样不同组之间也能直接比高低
        var hists = [
          { label: '前·压缩', data: d.hFc || [] },
          { label: '前·回弹', data: d.hFr || [] },
          { label: '后·压缩', data: d.hRc || [] },
          { label: '后·回弹', data: d.hRr || [] }
        ]
        var gmax = 1
        for (var gi = 0; gi < hists.length; gi++) {
          var arr = hists[gi].data
          for (var bi = 0; bi < arr.length; bi++) {
            var vv = parseFloat(arr[bi]) || 0
            if (vv > gmax) gmax = vv
          }
        }
        scope.groups = hists.map(function (g) {
          return {
            label: g.label,
            top: (g.data && g.data[0]) || 0,
            bars: (g.data || []).map(function (v) {
              var p = parseFloat(v) || 0
              return { h: Math.max(2, Math.round(p / gmax * 100)), p: p }
            })
          }
        })
      }

      // 扩展把全部字段压成 JSON 放在 d.tune 里（嵌套表直接传会丢）
      function unpack(d) {
        if (d && typeof d.tune === 'string' && d.tune.charAt(0) === '{') {
          try {
            var o = JSON.parse(d.tune)
            for (var k in o) d[k] = o[k]
          } catch (e) {}
        }
        return d
      }

      function poll() {
        bngApi.engineLua('extensions.roadProfile.getLive()', function (d) {
          if (!d) { scope.$applyAsync(function () { scope.alive = false }); return }
          d = unpack(d)
          scope.$applyAsync(function () {
            scope.d = d
            scope.alive = true
            build(d)
          })
        })
      }

      // 扩展主动推送（比 engineLua 回调可靠）
      scope.$on('roadProfileLive', function (e, d) {
        if (!d) return
        d = unpack(d)
        scope.$applyAsync(function () {
          scope.d = d
          scope.alive = true
          build(d)
        })
      })

      var timer = $interval(poll, 700)
      poll()

      scope.cmd = function (c) {
        bngApi.engineLua('extensions.roadProfile.' + c + '()')
        if (c === 'toggle') {
          scope.msg = (scope.d && scope.d.recording) ? '已停止并导出 CSV' : '开始记录'
        } else {
          scope.msg = '已导出 CSV'
        }
        $interval(function () { scope.msg = '' }, 2200, 1)
        $interval(poll, 400, 4)          // 操作后快速刷新几次
      }

      scope.reset = function () {
        bngApi.engineLua('extensions.roadProfile.start()')
        scope.msg = '缓冲已清空，重新记录'
        $interval(function () { scope.msg = '' }, 1500, 1)
        $interval(poll, 400, 3)
      }

      scope.$on('$destroy', function () { $interval.cancel(timer) })
    }
  }
}])
