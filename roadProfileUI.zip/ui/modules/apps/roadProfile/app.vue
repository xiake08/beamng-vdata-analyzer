<template>
  <div class="rp-root">
    <div class="rp-head">
      <div class="rp-dot" :class="{ on: d.recording }"></div>
      <span class="rp-title">路面抓包<small>ROAD PROFILE</small></span>
      <span class="rp-state">{{ d.recording ? '记录中' : '已停止' }}</span>
      <span class="rp-right"><b>{{ durText }}</b> · <b>{{ d.samples }}</b> 点 · <b>{{ distKm }}</b> km</span>
    </div>

    <div class="rp-veh" :title="vehTitle">
      🚗 {{ d.veh || '未知车辆' }}<span class="rp-cfg"><i>配置</i>{{ d.cfg || '?' }}</span>
    </div>

    <div v-if="!alive" class="rp-dead">连不上扩展（游戏需重启以加载 roadProfile）</div>

    <div class="rp-metrics">
      <div class="rp-mrow">
        <span>均速 <b>{{ vAvgKmh }}</b> km/h</span>
        <span class="rp-div"></span>
        <span>最高 <b class="small">{{ vMaxKmh }}</b> km/h</span>
      </div>
      <div class="rp-mrow">
        <span>悬挂强度 RMS</span>
        <span class="rp-div"></span>
        <span>前 <b class="small">{{ d.rmsF }}</b></span>
        <span>后 <b class="small">{{ d.rmsR }}</b></span>
      </div>
    </div>

    <div class="rp-hist">
      <div v-for="(g, gi) in groups" :key="gi" class="rp-grp" :class="{ rear: gi > 1 }">
        <div class="rp-gl">
          <span class="rp-lbl">{{ g.label }}</span>
          <span class="rp-top">{{ g.top }}%</span>
        </div>
        <div class="rp-bars" :title="g.label + '：柱高 = 该速度段占比'">
          <div v-for="(b, bi) in g.bars" :key="bi" class="rp-bar" :style="{ height: b.h + '%' }" :title="b.p + '%'"></div>
        </div>
      </div>
    </div>

    <div class="rp-wheels">
      <div v-for="(k, wi) in KEYS" :key="k" class="rp-wheel" :class="{ rear: wi > 1 }">
        <span class="rp-wk">{{ k }}</span>
        <span class="rp-wv">{{ fmt(d.loadNow[k]) }}</span>
        <span class="rp-wa">均 {{ fmt(d.load[k]) }}</span>
      </div>
    </div>

    <div class="rp-btns">
      <button title="清空缓存，重新开始记录" @click="reset">⟲ 清空重记</button>
      <button class="primary" title="开始 / 停止记录" @click="cmd('toggle')">{{ d.recording ? '⏸ 停止' : '▶ 开始' }}</button>
      <button title="把这次抓包导出成 CSV" @click="cmd('dump')">⤓ 导出</button>
    </div>
    <div class="rp-msg">{{ msg }}</div>
    <div class="rp-hint">开始 → 开一段 → 导出；柱子 = 每段路颠不颠</div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from "vue"
import { useBridge } from "@/bridge"

const { api } = useBridge()

const KEYS = ["FL", "FR", "RL", "RR"]

const d = ref({
  recording: 0, samples: 0, dist: 0, level: "-", n: 0,
  vAvg: 0, vMax: 0, rmsF: 0, rmsR: 0,
  hFc: [], hFr: [], hRc: [], hRr: [], bins: [],
  load: {}, loadNow: {}, airPct: {}, compSign: 1,
})
const alive = ref(false)
const msg = ref("")

const durText = computed(() => {
  const samples = parseInt(d.value.samples || 0, 10)
  const sec = samples / 10
  const mm = Math.floor(sec / 60)
  const ss = Math.floor(sec % 60)
  return (mm > 0 ? mm + "分" : "") + ss + "秒"
})

const distKm = computed(() => ((parseFloat(d.value.dist) || 0) / 1000).toFixed(2))
const vAvgKmh = computed(() => Math.round((parseFloat(d.value.vAvg) || 0) * 3.6))
const vMaxKmh = computed(() => Math.round((parseFloat(d.value.vMax) || 0) * 3.6))
const vehTitle = computed(() => `${d.value.vehKey || ""} / ${d.value.cfgKey || ""}`)

function fmt(v) {
  if (v === undefined || v === null || v === "") return "-"
  const n = parseFloat(v)
  return Number.isFinite(n) ? (Math.round(n * 10) / 10) : v
}

// 四个方向共用一个最大值，组与组之间可以直接比高低
const groups = computed(() => {
  const lists = [
    { label: "前·压缩", data: d.value.hFc || [] },
    { label: "前·回弹", data: d.value.hFr || [] },
    { label: "后·压缩", data: d.value.hRc || [] },
    { label: "后·回弹", data: d.value.hRr || [] },
  ]
  let gmax = 1
  for (const g of lists) {
    for (const v of g.data) {
      const n = parseFloat(v) || 0
      if (n > gmax) gmax = n
    }
  }
  return lists.map(g => ({
    label: g.label,
    top: g.data && g.data.length ? g.data[0] : 0,
    bars: g.data.map(v => {
      const p = parseFloat(v) || 0
      return { h: Math.max(2, Math.round((p / gmax) * 100)), p }
    }),
  }))
})

// 扩展把全部分字段压成 JSON 塞在 d.tune 里（嵌套表直接传会丢）
function unpack(data) {
  if (data && typeof data.tune === "string" && data.tune.charAt(0) === "{") {
    try {
      const o = JSON.parse(data.tune)
      for (const k in o) data[k] = o[k]
    } catch (e) {
      // ignore
    }
  }
  return data
}

let failCount = 0

function poll() {
  api.engineLua("extensions.roadProfile.getLive()", data => {
    if (!data) {
      // 换车/换图瞬间可能取不到数据，连续几次都空才认输，别闪
      failCount++
      if (failCount >= 3) alive.value = false
      return
    }
    failCount = 0
    d.value = unpack(data)
    alive.value = true
  })
}

function flash(text) {
  msg.value = text
  clearTimeout(flash.timer)
  flash.timer = setTimeout(() => (msg.value = ""), 1500)
}

function cmd(c) {
  api.engineLua("extensions.roadProfile." + c + "()")
  flash(c === "toggle" ? "已切换" : "已导出")
  for (let i = 0; i < 3; i++) setTimeout(poll, 400 * (i + 1))
}

function reset() {
  api.engineLua("extensions.roadProfile.start()")
  flash("缓存已清空，重新记录")
  for (let i = 0; i < 3; i++) setTimeout(poll, 400 * (i + 1))
}

let timer = null
onMounted(() => {
  poll()
  timer = setInterval(poll, 700)
})
onUnmounted(() => {
  if (timer) clearInterval(timer)
  clearTimeout(flash.timer)
})
</script>

<style scoped>
.rp-root {
  --line: rgba(110, 150, 195, 0.32);
  --ink: #eef4fa;
  --muted: #93a6ba;
  --dim: #6d8095;
  --green: #35d07f;
  --front: #6fa8d8;
  --front2: #2c6fa8;
  --rear: #e0b36a;
  --rear2: #a87a32;
  font-family: 'Microsoft YaHei', 'Noto Sans SC', sans-serif;
  font-size: 11px;
  color: var(--ink);
  background: linear-gradient(180deg, rgba(24, 32, 44, 0.94), rgba(10, 14, 20, 0.94));
  border: 1px solid var(--line);
  border-radius: 10px;
  padding: 8px 10px;
  height: 100%;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 6px;
  overflow: hidden;
  font-variant-numeric: tabular-nums;
  box-shadow: 0 10px 26px -14px rgba(0, 0, 0, 0.9), inset 0 1px 0 rgba(255, 255, 255, 0.05);
}

.rp-head { display: flex; align-items: center; gap: 7px; flex: 0 0 auto; }
.rp-dot { width: 8px; height: 8px; border-radius: 50%; background: #5d6b7a; flex: 0 0 auto; }
.rp-dot.on { background: var(--green); box-shadow: 0 0 8px rgba(53, 208, 127, 0.8); animation: rp-pulse 1.6s infinite; }
@keyframes rp-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.45; } }
.rp-title { font-size: 12px; font-weight: 700; letter-spacing: 0.4px; }
.rp-title small { font-size: 8px; font-weight: 500; color: var(--dim); letter-spacing: 1.2px; margin-left: 4px; }
.rp-state { font-size: 10px; color: var(--muted); }
.rp-dot.on + .rp-state { color: var(--green); }
.rp-right { margin-left: auto; font-size: 10px; color: var(--muted); white-space: nowrap; }
.rp-right b { color: #fff; font-weight: 600; }

.rp-veh {
  flex: 0 0 auto; font-size: 11px; color: #d7e6f5; background: rgba(60, 92, 132, 0.3);
  border: 1px solid rgba(120, 160, 210, 0.18); border-radius: 6px;
  padding: 3px 7px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.rp-cfg { color: #9fd6b8; margin-left: 8px; }
.rp-cfg i { color: var(--dim); font-style: normal; margin-right: 3px; }

.rp-metrics { display: flex; flex-direction: column; gap: 3px; flex: 0 0 auto; }
.rp-mrow { display: flex; align-items: baseline; gap: 6px; color: var(--muted); font-size: 10.5px; }
.rp-mrow b { color: #fff; font-size: 13px; font-weight: 700; }
.rp-mrow b.small { font-size: 11px; }
.rp-div { width: 1px; height: 10px; background: rgba(140, 170, 205, 0.22); align-self: center; }

.rp-hist { display: flex; gap: 7px; flex: 1 1 auto; min-height: 62px; }
.rp-grp { flex: 1 1 0; display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.rp-gl { display: flex; align-items: baseline; justify-content: space-between; gap: 2px; }
.rp-lbl { font-size: 9px; color: var(--muted); white-space: nowrap; }
.rp-top { font-size: 10px; font-weight: 700; color: var(--front); }
.rp-grp.rear .rp-top { color: var(--rear); }
.rp-bars {
  display: flex; align-items: flex-end; gap: 1px; width: 100%; flex: 1 1 auto;
  border-bottom: 1px solid rgba(130, 165, 205, 0.25); padding-bottom: 1px;
}
.rp-bar { flex: 1 1 0; min-height: 1px; border-radius: 1px 1px 0 0; background: linear-gradient(180deg, var(--front), var(--front2)); }
.rp-grp.rear .rp-bar { background: linear-gradient(180deg, var(--rear), var(--rear2)); }

.rp-wheels { display: flex; gap: 5px; flex: 0 0 auto; }
.rp-wheel {
  flex: 1 1 0; border-radius: 6px; padding: 3px 5px;
  background: rgba(60, 92, 132, 0.22); border: 1px solid rgba(120, 160, 210, 0.16);
  display: flex; flex-direction: column; gap: 1px;
}
.rp-wheel.rear { background: rgba(120, 92, 46, 0.2); border-color: rgba(200, 160, 95, 0.2); }
.rp-wk { font-size: 8.5px; color: var(--dim); letter-spacing: 0.5px; }
.rp-wv { font-size: 11px; font-weight: 700; color: #eaf3fb; }
.rp-wa { font-size: 8.5px; color: var(--dim); }

.rp-btns { display: flex; gap: 5px; flex: 0 0 auto; }
.rp-btns button {
  flex: 1 1 0; height: 24px; border-radius: 6px; cursor: pointer;
  font-family: inherit; font-size: 11px; color: #e8f1f9;
  background: rgba(56, 84, 120, 0.55); border: 1px solid rgba(120, 160, 205, 0.35);
  transition: background 0.12s, border-color 0.12s;
}
.rp-btns button:hover { background: rgba(78, 112, 156, 0.75); border-color: rgba(150, 195, 235, 0.55); }
.rp-btns button:active { transform: translateY(1px); }
.rp-btns button.primary {
  background: linear-gradient(180deg, #2e9e68, #217a4f);
  border-color: rgba(90, 220, 155, 0.5); color: #eafff4; font-weight: 700;
}
.rp-btns button.primary:hover { background: linear-gradient(180deg, #39b577, #288a5b); }

.rp-msg { font-size: 9.5px; color: #ffd479; min-height: 11px; flex: 0 0 auto; }
.rp-dead { color: #ff8a80; font-size: 10px; }
.rp-hint {
  font-size: 8.5px; color: #66798e; flex: 0 0 auto; white-space: nowrap;
  overflow: hidden; text-overflow: ellipsis;
}

@media (max-height: 280px) {
  .rp-root { gap: 4px; padding: 6px 8px; }
  .rp-hist { min-height: 54px; }
  .rp-hint { display: none; }
  .rp-msg { min-height: 0; }
}
</style>
