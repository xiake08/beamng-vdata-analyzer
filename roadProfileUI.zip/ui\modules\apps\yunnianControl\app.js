// 云辇控制面板 —— 通过 roadProfile 扩展转发到车辆控制器
angular.module('beamng.apps')

.directive('yunnianControl', ['$interval', function ($interval) {
  return {
    templateUrl: '/ui/modules/apps/yunnianControl/app.html',
    replace: true,
    restrict: 'E',
    scope: true,
    link: function (scope, element, attrs) {
      scope.show = false
      scope.msg = '点按钮控制车身'

      var NAMES = {
        height_up: '车高 +', height_down: '车高 −', height_auto: '车高自动',
        dance: '跳舞', jump: '起跳', cdc: 'CDC 开关',
        pivot_ccw: '掉头 逆时针', pivot_cw: '掉头 顺时针'
      }

      scope.cmd = function (c) {
        bngApi.engineLua('extensions.roadProfile.ync("' + c + '")')
        scope.msg = '已发送：' + (NAMES[c] || c)
        $interval(function () { scope.msg = '点按钮控制车身' }, 2000, 1)
      }

      // 只在小米 YU7 上显示（配置名这个版本读不到，用车型判断）
      function checkAvail() {
        bngApi.engineLua('extensions.roadProfile.getLive()', function (d) {
          if (!d) return
          var key = String(d.vehKey || '').toLowerCase()
          var name = String(d.veh || '')
          var isYu7 = key.indexOf('xiaomiyu') >= 0 || name.indexOf('YU7') >= 0 || name.indexOf('小米') >= 0
          scope.$applyAsync(function () { scope.show = isYu7 })
        })
      }
      $interval(checkAvail, 700)
      checkAvail()

      scope.$on('$destroy', function () {})
    }
  }
}])
